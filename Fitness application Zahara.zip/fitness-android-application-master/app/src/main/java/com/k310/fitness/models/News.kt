package com.k310.fitness.models

class News(
    var author: String,
    var title: String,
    var description: String,
    var url: String
)