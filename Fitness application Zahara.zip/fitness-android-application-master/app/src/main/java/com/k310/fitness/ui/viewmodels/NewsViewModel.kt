package com.k310.fitness.ui.viewmodels

import androidx.lifecycle.ViewModel

class NewsViewModel : ViewModel() {

}