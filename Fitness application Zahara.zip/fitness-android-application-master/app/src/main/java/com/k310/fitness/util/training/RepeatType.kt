package com.k310.fitness.util.training

enum class RepeatType {
    ONE_TIME, WEEKLY
}