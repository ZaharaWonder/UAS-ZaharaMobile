package com.k310.fitness.util.training

enum class TrainingType {
    CYCLING, RUNNING
}